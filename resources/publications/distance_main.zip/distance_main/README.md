# distance_main

This package reproduces the SDE and DSDE experiments for the paper *Using Semantic Distance to Estimate Uncertainty in LLM-Based Code Generation*. It contains the candidate sampling, fuzzing, execution clustering, metric computation, ablation, diagnostic, abstention, timeout, and case-study code paths for the paper methods only.

## Prerequisites

Python 3.10 or newer is required. Java experiments require a JDK with `javac` and `java`; C++ experiments require `g++`, `c++`, or `clang++`. The paper ran experiments on an Apple M4 Pro with 24 GB RAM.

## Setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Add API keys to `.env`, place benchmark files under `data/`, then run:

```bash
bash run.sh
```

Outputs are written to `results/`.
