#!/usr/bin/env bash
cd "$(dirname "$0")"
set -euo pipefail
[ -f .env ] && set -a && source .env && set +a
mkdir -p results
python -m scripts.rq1_lcb_main
python -m scripts.rq2_mbpp
python -m scripts.rq2_humaneval_x
python -m scripts.rq2_bigcodebench
python -m scripts.rq2_temperature_sweep
python -m scripts.rq2_deepseek
python -m scripts.rq3_kn_sweep
python -m scripts.rq3_runtime
python -m scripts.rq4_learned_weights
python -m scripts.rq4_seed_free
python -m scripts.rq4_fuzz_seeds
python -m scripts.appendix_diagnostics
python -m scripts.appendix_abstention
python -m scripts.appendix_timeout
python -m scripts.appendix_case_studies
