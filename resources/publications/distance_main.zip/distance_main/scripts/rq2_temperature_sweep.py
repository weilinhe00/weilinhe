from src.workflows import rq2_temperature_sweep

def main():
    rq2_temperature_sweep()

if __name__ == "__main__":
    main()
