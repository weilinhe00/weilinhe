from src.workflows import appendix_abstention

def main():
    appendix_abstention()

if __name__ == "__main__":
    main()
