from src.workflows import rq2_mbpp

def main():
    rq2_mbpp()

if __name__ == "__main__":
    main()
