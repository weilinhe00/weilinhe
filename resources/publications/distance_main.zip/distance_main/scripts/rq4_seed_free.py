from src.workflows import rq4_seed_free

def main():
    rq4_seed_free()

if __name__ == "__main__":
    main()
