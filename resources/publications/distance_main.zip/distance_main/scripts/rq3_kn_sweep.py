from src.workflows import rq3_kn_sweep

def main():
    rq3_kn_sweep()

if __name__ == "__main__":
    main()
