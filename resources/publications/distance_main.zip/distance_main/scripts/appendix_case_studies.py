from src.workflows import appendix_case_studies

def main():
    appendix_case_studies()

if __name__ == "__main__":
    main()
