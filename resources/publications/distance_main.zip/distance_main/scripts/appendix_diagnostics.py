from src.workflows import appendix_diagnostics

def main():
    appendix_diagnostics()

if __name__ == "__main__":
    main()
