from src.workflows import rq1

def main():
    rq1()

if __name__ == "__main__":
    main()
