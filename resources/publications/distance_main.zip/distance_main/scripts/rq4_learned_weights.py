from src.workflows import rq4_learned_weights

def main():
    rq4_learned_weights()

if __name__ == "__main__":
    main()
