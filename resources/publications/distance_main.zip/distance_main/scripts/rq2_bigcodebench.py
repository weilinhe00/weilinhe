from src.workflows import rq2_bigcodebench

def main():
    rq2_bigcodebench()

if __name__ == "__main__":
    main()
