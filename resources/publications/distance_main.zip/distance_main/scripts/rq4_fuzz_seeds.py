from src.workflows import rq4_fuzz_seeds

def main():
    rq4_fuzz_seeds()

if __name__ == "__main__":
    main()
