from src.workflows import rq2_deepseek

def main():
    rq2_deepseek()

if __name__ == "__main__":
    main()
