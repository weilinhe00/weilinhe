from src.workflows import rq3_runtime

def main():
    rq3_runtime()

if __name__ == "__main__":
    main()
