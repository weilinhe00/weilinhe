from src.workflows import rq2_humaneval_x

def main():
    rq2_humaneval_x()

if __name__ == "__main__":
    main()
