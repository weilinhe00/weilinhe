from src.workflows import appendix_timeout

def main():
    appendix_timeout()

if __name__ == "__main__":
    main()
