from pathlib import Path
import gzip
import json

def read_records(path):
    path = Path(path)
    if not path.exists():
        raise RuntimeError(f"Missing data file: {path}")
    text = path.name
    if text.endswith(".jsonl.gz"):
        return list(read_jsonl_gz(path))
    if text.endswith(".jsonl"):
        return list(read_jsonl(path))
    if text.endswith(".json.gz"):
        with gzip.open(path, "rt", encoding="utf-8") as handle:
            data = json.load(handle)
    elif text.endswith(".json"):
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
    else:
        raise RuntimeError(f"Unsupported data file: {path}")
    if isinstance(data, dict):
        if "data" in data and isinstance(data["data"], list):
            return data["data"]
        return list(data.values())
    return data

def read_jsonl(path):
    with open(path, "r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                yield json.loads(line)

def read_jsonl_gz(path):
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                yield json.loads(line)

def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as handle:
        json.dump(value, handle, indent=2, ensure_ascii=False)
    tmp.replace(path)

def normalize_problem(raw, language):
    task_id = raw.get("task_id", raw.get("id", raw.get("question_id", "")))
    prompt = raw.get("prompt", raw.get("code", raw.get("declaration", raw.get("text", ""))))
    tests = raw.get("test", raw.get("tests", raw.get("test_list", raw.get("input_output", ""))))
    entry_point = raw.get("entry_point", raw.get("starter_code_entry_point", raw.get("function_name", "")))
    difficulty = raw.get("difficulty", raw.get("contest_difficulty", "All"))
    return {
        "task_id": str(task_id),
        "prompt": prompt,
        "tests": tests,
        "entry_point": entry_point,
        "difficulty": str(difficulty).capitalize(),
        "language": raw.get("language", language),
        "raw": raw,
    }
