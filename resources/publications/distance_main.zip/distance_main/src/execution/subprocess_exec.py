from pathlib import Path
import shutil
import subprocess
import tempfile

def compiler_for(language):
    if language == "java":
        if not shutil.which("javac") or not shutil.which("java"):
            raise RuntimeError("javac and java are required")
        return "javac"
    for cmd in ["g++", "c++", "clang++"]:
        if shutil.which(cmd):
            return cmd
    raise RuntimeError("C++ compiler is required")

def run_command(cmd, cwd, timeout):
    try:
        result = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return "TimeoutError"
    if result.returncode != 0:
        text = result.stderr.strip() or result.stdout.strip()
        return f"RuntimeError: {text[:200]}"
    return result.stdout.strip() or "pass"

def execute_java(problem, timeout):
    compiler_for("java")
    outputs = []
    prompt = str(problem.get("prompt", ""))
    tests = str(problem.get("tests", ""))
    for candidate in problem.get("candidates", []):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "Main.java"
            path.write_text(prompt + "\n" + str(candidate) + "\n" + tests, encoding="utf-8")
            compile_out = run_command(["javac", "Main.java"], tmp, max(timeout, 1.0) * 20)
            if compile_out.startswith("RuntimeError") or compile_out == "TimeoutError":
                outputs.append([compile_out])
            else:
                outputs.append([run_command(["java", "Main"], tmp, max(timeout, 1.0) * 20)])
    return outputs

def execute_cpp(problem, timeout):
    compiler = compiler_for("cpp")
    outputs = []
    prompt = str(problem.get("prompt", ""))
    tests = str(problem.get("tests", ""))
    for candidate in problem.get("candidates", []):
        with tempfile.TemporaryDirectory() as tmp:
            src = Path(tmp) / "main.cpp"
            exe = Path(tmp) / "main"
            src.write_text(prompt + "\n" + str(candidate) + "\n" + tests, encoding="utf-8")
            compile_out = run_command([compiler, "-std=c++17", "main.cpp", "-o", "main"], tmp, max(timeout, 1.0) * 20)
            if compile_out.startswith("RuntimeError") or compile_out == "TimeoutError":
                outputs.append([compile_out])
            else:
                outputs.append([run_command([str(exe)], tmp, max(timeout, 1.0) * 20)])
    return outputs

def execute_external(problem, timeout):
    language = str(problem.get("language", "")).lower()
    if language == "java":
        return execute_java(problem, timeout)
    if language in {"cpp", "c++"}:
        return execute_cpp(problem, timeout)
    raise RuntimeError(f"Unsupported external language: {language}")
