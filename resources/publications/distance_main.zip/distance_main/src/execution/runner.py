from src.execution.python_exec import execute_python, execute_python_tests
from src.execution.subprocess_exec import execute_external

def execute_problem(problem, inputs, timeout):
    language = str(problem.get("language", "python")).lower()
    if problem.get("raw", {}).get("constraint_vectors"):
        return problem["raw"]["constraint_vectors"]
    if problem.get("raw", {}).get("outputs"):
        return problem["raw"]["outputs"]
    if language == "python":
        return execute_python(problem, inputs, timeout)
    return execute_external(problem, timeout)

def correctness(problem, timeout):
    language = str(problem.get("language", "python")).lower()
    raw = problem.get("raw", {})
    if raw.get("success_rate_list"):
        values = [float(x) for x in raw["success_rate_list"]]
        return values[0], values
    if raw.get("pass_rates"):
        values = [float(x) for x in raw["pass_rates"]]
        return values[0], values
    if language == "python":
        values = execute_python_tests(problem, timeout)
        return values[0] if values else 0.0, values
    return 0.0, []
