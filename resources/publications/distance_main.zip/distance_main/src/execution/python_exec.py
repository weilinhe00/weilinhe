import hashlib
import inspect
import multiprocessing as mp
import textwrap

def compact(value):
    text = str(value)
    if len(text) > 500:
        return "HASH:" + hashlib.md5(text.encode("utf-8")).hexdigest()
    return text

def full_python_code(prompt, candidate, entry_point):
    if f"def {entry_point}" in candidate:
        return candidate
    if prompt.rstrip().endswith(":"):
        body = []
        for line in candidate.splitlines():
            if line and not line[0].isspace():
                body.append("    " + line)
            else:
                body.append(line)
        return prompt + "\n" + "\n".join(body)
    return prompt + "\n" + candidate

def _worker(code, entry_point, args, queue):
    ns = {}
    try:
        exec("import math, itertools, collections, functools, heapq, bisect, re, string\nfrom typing import *", ns)
        exec(compile(code, "<candidate>", "exec"), ns)
        fn = ns.get(entry_point)
        if fn is None:
            queue.put("NameError: entry_point not found")
            return
        try:
            sig = inspect.signature(fn)
            count = len([p for p in sig.parameters.values() if p.name != "self"])
        except Exception:
            count = None
        if isinstance(args, (list, tuple)) and (count is None or count != 1):
            value = fn(*args)
        else:
            value = fn(args)
        queue.put(compact(value))
    except BaseException as exc:
        queue.put(f"{type(exc).__name__}: {str(exc)[:200]}")

def execute_call(code, entry_point, args, timeout):
    ctx = mp.get_context("fork")
    queue = ctx.Queue()
    proc = ctx.Process(target=_worker, args=(code, entry_point, args, queue))
    proc.start()
    proc.join(timeout)
    if proc.is_alive():
        proc.kill()
        proc.join()
        return "TimeoutError"
    try:
        return queue.get_nowait()
    except Exception:
        return f"RuntimeError: exit {proc.exitcode}"

def execute_python(problem, inputs, timeout):
    outputs = []
    for candidate in problem.get("candidates", []):
        code = full_python_code(str(problem.get("prompt", "")), str(candidate), str(problem.get("entry_point", "")))
        outputs.append([execute_call(code, str(problem.get("entry_point", "")), args, timeout) for args in inputs])
    return outputs

def execute_python_tests(problem, timeout):
    results = []
    tests = problem.get("tests", "")
    for candidate in problem.get("candidates", []):
        code = full_python_code(str(problem.get("prompt", "")), str(candidate), str(problem.get("entry_point", "")))
        results.append(run_whole_test(code, str(problem.get("entry_point", "")), str(tests), timeout))
    return results

def _test_worker(code, entry_point, tests, queue):
    ns = {}
    try:
        exec("import math, itertools, collections, functools, heapq, bisect, re, string\nfrom typing import *", ns)
        exec(compile(code, "<candidate>", "exec"), ns)
        candidate = ns.get(entry_point)
        ns["candidate"] = candidate
        exec(compile(tests, "<tests>", "exec"), ns)
        queue.put(1.0)
    except AssertionError:
        queue.put(0.0)
    except BaseException:
        queue.put(0.0)

def run_whole_test(code, entry_point, tests, timeout):
    ctx = mp.get_context("fork")
    queue = ctx.Queue()
    proc = ctx.Process(target=_test_worker, args=(code, entry_point, tests, queue))
    proc.start()
    proc.join(timeout)
    if proc.is_alive():
        proc.kill()
        proc.join()
        return 0.0
    try:
        return float(queue.get_nowait())
    except Exception:
        return 0.0
