from collections import Counter
from src.metrics.distance import crash_type

def valid_exec_rate(outputs):
    total = 0
    valid = 0
    for signature in outputs:
        for value in signature:
            total += 1
            valid += int(crash_type(value) is None)
    return valid / total if total else 0.0

def unique_input_rate(inputs):
    if not inputs:
        return 0.0
    keys = [repr(x) for x in inputs]
    return len(set(keys)) / len(keys)

def crash_pollution_rate(outputs):
    if not outputs:
        return 0.0
    bad = sum(1 for signature in outputs if any(crash_type(value) is not None for value in signature))
    return bad / len(outputs)

def output_diversity(outputs):
    if not outputs:
        return 0.0
    keys = [tuple(map(str, signature)) for signature in outputs]
    counts = Counter(keys)
    return len(counts) / len(outputs)
