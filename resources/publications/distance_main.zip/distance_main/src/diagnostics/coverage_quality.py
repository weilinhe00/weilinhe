import coverage
from src.execution.python_exec import full_python_code

def python_coverage(problem, inputs):
    entry = str(problem.get("entry_point", ""))
    candidate = problem.get("candidates", [""])[0]
    code = full_python_code(str(problem.get("prompt", "")), str(candidate), entry)
    cov = coverage.Coverage(branch=True)
    ns = {}
    try:
        cov.start()
        exec(compile(code, "<coverage_candidate>", "exec"), ns)
        fn = ns.get(entry)
        for args in inputs:
            try:
                fn(*args if isinstance(args, list) else [args])
            except Exception:
                pass
        cov.stop()
        data = cov.get_data()
        lines = set()
        arcs = set()
        for filename in data.measured_files():
            lines.update(data.lines(filename) or [])
            arcs.update(data.arcs(filename) or [])
        return {"line_coverage": float(len(lines)), "branch_coverage": float(len(arcs))}
    except Exception:
        try:
            cov.stop()
        except Exception:
            pass
        return {"line_coverage": 0.0, "branch_coverage": 0.0}
