import os

def required_env(name):
    value = os.environ.get(name)
    if not value:
        raise RuntimeError(f"{name} is not set")
    return value

def provider_for_model(model):
    low = model.lower()
    if "claude" in low or "anthropic" in low:
        return "anthropic"
    if "gemini" in low:
        return "google"
    if "deepseek" in low:
        return "deepseek"
    return "openai"

def call_model(prompt, model, temperature):
    provider = provider_for_model(model)
    if provider == "anthropic":
        return call_anthropic(prompt, model, temperature)
    if provider == "google":
        return call_google(prompt, model, temperature)
    if provider == "deepseek":
        return call_deepseek(prompt, model, temperature)
    return call_openai(prompt, model, temperature)

def call_openai(prompt, model, temperature):
    from openai import OpenAI
    client = OpenAI(api_key=required_env("OPENAI_API_KEY"))
    response = client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        temperature=temperature,
        max_tokens=2048,
    )
    return response.choices[0].message.content or ""

def call_deepseek(prompt, model, temperature):
    from openai import OpenAI
    client = OpenAI(api_key=required_env("DEEPSEEK_API_KEY"), base_url="https://api.deepseek.com")
    response = client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        temperature=temperature,
        max_tokens=2048,
    )
    return response.choices[0].message.content or ""

def call_anthropic(prompt, model, temperature):
    import anthropic
    client = anthropic.Anthropic(api_key=required_env("ANTHROPIC_API_KEY"))
    response = client.messages.create(
        model=model,
        max_tokens=2048,
        temperature=temperature,
        messages=[{"role": "user", "content": prompt}],
    )
    return response.content[0].text if response.content else ""

def call_google(prompt, model, temperature):
    import google.generativeai as genai
    genai.configure(api_key=required_env("GOOGLE_API_KEY"))
    generation_config = {"temperature": temperature, "max_output_tokens": 2048}
    response = genai.GenerativeModel(model).generate_content(prompt, generation_config=generation_config)
    return response.text or ""

def strip_fence(text):
    text = text.strip()
    if "```" not in text:
        return text
    parts = text.split("```")
    blocks = [part for index, part in enumerate(parts) if index % 2 == 1]
    if not blocks:
        return text
    block = blocks[0].strip()
    lines = block.splitlines()
    if lines and lines[0].strip().lower() in {"python", "java", "cpp", "c++"}:
        lines = lines[1:]
    return "\n".join(lines).strip()
