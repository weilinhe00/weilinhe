from pathlib import Path
from tqdm import tqdm
from src.records import write_json
from src.sampling.llm import call_model, strip_fence

def prompt_for(problem):
    language = str(problem["language"]).lower()
    if language == "java":
        return "\n".join([
            "Complete the Java method or class.",
            "Return only compilable code without markdown.",
            str(problem["prompt"]),
        ])
    if language == "cpp":
        return "\n".join([
            "Complete the C++ function.",
            "Return only compilable code without markdown.",
            str(problem["prompt"]),
        ])
    return "\n".join([
        "Complete the Python function.",
        "Return only code without markdown.",
        str(problem["prompt"]),
    ])

def generate_candidates(problems, model, temperature, k, output_file, force=False):
    output_file = Path(output_file)
    existing = {}
    if output_file.exists() and not force:
        import json
        with open(output_file, "r", encoding="utf-8") as handle:
            existing = {item["task_id"]: item for item in json.load(handle)}
    results = dict(existing)
    for problem in tqdm(problems, desc=f"sampling {model}", ncols=100):
        task_id = problem["task_id"]
        present = results.get(task_id, {}).get("candidates", [])
        if len([x for x in present if x]) >= k and not force:
            continue
        candidates = list(present)
        while len(candidates) < k:
            raw = call_model(prompt_for(problem), model, temperature)
            candidates.append(strip_fence(raw))
        item = dict(problem)
        item.pop("raw", None)
        item["model"] = model
        item["temperature"] = temperature
        item["candidates"] = candidates[:k]
        results[task_id] = item
        write_json(output_file, list(results.values()))
    write_json(output_file, list(results.values()))
    return list(results.values())
