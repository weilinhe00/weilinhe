import ast
import copy
import json
import random
import re

def key(value):
    return json.dumps(value, sort_keys=True, default=str)

def literal_args_from_python_tests(test_text, entry_point):
    seeds = []
    seen = set()
    try:
        tree = ast.parse(str(test_text))
    except SyntaxError:
        return seeds
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        name = ""
        if isinstance(node.func, ast.Name):
            name = node.func.id
        elif isinstance(node.func, ast.Attribute):
            name = node.func.attr
        if name not in {"candidate", entry_point}:
            continue
        try:
            args = [ast.literal_eval(arg) for arg in node.args]
        except Exception:
            continue
        marker = key(args)
        if marker not in seen:
            seeds.append(args)
            seen.add(marker)
    return seeds

def literal_args_from_text(text, entry_point):
    seeds = []
    seen = set()
    if not entry_point:
        return seeds
    pattern = re.compile(re.escape(entry_point) + r"\s*\((.*?)\)")
    for match in pattern.finditer(str(text)):
        raw = match.group(1).strip()
        if not raw:
            continue
        try:
            args = list(ast.literal_eval(f"({raw},)"))
        except Exception:
            continue
        marker = key(args)
        if marker not in seen:
            seeds.append(args)
            seen.add(marker)
    return seeds

def mutate_value(value, rng):
    if isinstance(value, bool):
        return not value
    if isinstance(value, int):
        return rng.choice([0, 1, -1, value + 1, value - 1, value * 2])
    if isinstance(value, float):
        return rng.choice([0.0, 1.0, -1.0, value + 1.0, value - 1.0, value * 2.0])
    if isinstance(value, str):
        return rng.choice(["", value + "a", value[::-1], value.upper(), value.lower()])
    if isinstance(value, list):
        out = copy.deepcopy(value)
        choice = rng.choice(["empty", "append", "drop", "mutate"])
        if choice == "empty":
            return []
        if choice == "append":
            return out + ([mutate_value(out[-1], rng)] if out else [0])
        if choice == "drop":
            return out[:-1]
        if out:
            pos = rng.randrange(len(out))
            out[pos] = mutate_value(out[pos], rng)
        return out
    if isinstance(value, tuple):
        return tuple(mutate_value(list(value), rng))
    if isinstance(value, dict):
        out = copy.deepcopy(value)
        if out:
            k = rng.choice(list(out.keys()))
            out[k] = mutate_value(out[k], rng)
        return out
    return value

def mutate_args(args, rng):
    if not args:
        return []
    out = copy.deepcopy(args)
    pos = rng.randrange(len(out))
    out[pos] = mutate_value(out[pos], rng)
    return out

def default_seed(entry_point):
    return [[0], [1], [-1], [[]], [["a"]], [""]]

def infer_random_args(seeds, rng):
    if not seeds:
        return rng.choice(default_seed(""))
    base = rng.choice(seeds)
    return [mutate_value(x, rng) for x in base]

def make_inputs(problem, n, seed=42, seed_free=False):
    rng = random.Random(seed)
    entry_point = problem.get("entry_point", "")
    seeds = []
    raw = problem.get("raw", {})
    if not seed_free:
        if isinstance(raw.get("inputs"), list):
            seeds.extend(raw["inputs"])
        seeds.extend(literal_args_from_python_tests(problem.get("tests", ""), entry_point))
        seeds.extend(literal_args_from_text(problem.get("prompt", ""), entry_point))
        seeds.extend(literal_args_from_text(problem.get("tests", ""), entry_point))
    if not seeds:
        seeds = default_seed(entry_point)
    inputs = []
    seen = set()
    for item in seeds:
        args = item if isinstance(item, list) else [item]
        marker = key(args)
        if marker not in seen:
            inputs.append(args)
            seen.add(marker)
        if len(inputs) >= n:
            return inputs[:n]
    attempts = 0
    while len(inputs) < n and attempts < n * 200:
        attempts += 1
        if seed_free:
            args = infer_random_args(seeds, rng)
        else:
            args = mutate_args(rng.choice(seeds), rng)
        marker = key(args)
        if marker not in seen:
            inputs.append(args)
            seen.add(marker)
    return inputs[:n]
