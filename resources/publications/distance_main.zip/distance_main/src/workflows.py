from pathlib import Path
import csv
import statistics
import time
from src.config import load_config, results_dir, data_path, distance_config
from src.records import read_records, normalize_problem, write_json
from src.sampling.candidates import generate_candidates
from src.fuzzing.generic import make_inputs
from src.execution.runner import execute_problem, correctness
from src.metrics.sde_dsde import compute_sde_dsde
from src.evaluation.stats import summarize, write_csv
from src.evaluation.weights import learn_weights
from src.evaluation.abstention import abstention_cv
from src.diagnostics.input_quality import valid_exec_rate, unique_input_rate, crash_pollution_rate, output_diversity
from src.diagnostics.coverage_quality import python_coverage

def slug(value):
    return str(value).replace("/", "_").replace(" ", "_").replace(".", "_")

def benchmark_problems(cfg, benchmark, limit=0):
    spec = cfg["benchmarks"][benchmark]
    records = read_records(data_path(cfg, benchmark))
    problems = [normalize_problem(item, spec.get("language", "python")) for item in records]
    return problems[:limit] if limit else problems

def raw_candidates(problem):
    raw = problem.get("raw", {})
    for key in ["candidates", "code_list", "completion", "completions", "solutions"]:
        value = raw.get(key)
        if isinstance(value, list):
            return [str(x) for x in value]
    return []

def attach_candidates_from_data(problems, k):
    output = []
    for problem in problems:
        candidates = raw_candidates(problem)
        item = dict(problem)
        item["candidates"] = candidates[:k]
        output.append(item)
    return output

def need_sampling(problems, k):
    return any(len(raw_candidates(problem)) < k for problem in problems)

def candidate_records(cfg, benchmark, model, temperature, k, out_dir, force=False, limit=0):
    problems = benchmark_problems(cfg, benchmark, limit)
    if need_sampling(problems, k):
        path = out_dir / f"{slug(benchmark)}_{slug(model)}_{temperature}_candidates.json"
        return generate_candidates(problems, model, temperature, k, path, force=force)
    return attach_candidates_from_data(problems, k)

def evaluate_candidate_records(records, cfg, n, timeout, seed, seed_free=False, selected_ids=None):
    rows = []
    details = []
    dcfg = distance_config(cfg)
    for problem in records:
        if selected_ids and problem["task_id"] not in selected_ids:
            continue
        inputs = make_inputs(problem, n, seed=seed, seed_free=seed_free)
        started = time.perf_counter()
        outputs = execute_problem(problem, inputs, timeout)
        elapsed = time.perf_counter() - started
        metric = compute_sde_dsde(outputs, dcfg)
        pass_at_1, success = correctness(problem, timeout)
        partial = float(success[0]) if success else float(pass_at_1)
        row = {
            "task_id": problem["task_id"],
            "difficulty": problem.get("difficulty", "All"),
            "pass_at_1": int(float(pass_at_1) == 1.0),
            "partial_pass_at_1": partial,
            "sde": metric["sde"],
            "dsde": metric["dsde"],
            "runtime_seconds": elapsed,
            "valid_exec_rate": valid_exec_rate(outputs),
            "unique_input_rate": unique_input_rate(inputs),
            "crash_pollution_rate": crash_pollution_rate(outputs),
            "output_diversity": output_diversity(outputs),
        }
        if str(problem.get("language", "")).lower() == "python":
            row.update(python_coverage(problem, inputs))
        else:
            row.update({"line_coverage": 0.0, "branch_coverage": 0.0})
        rows.append(row)
        detail = dict(row)
        detail["inputs"] = inputs
        detail["outputs"] = outputs
        details.append(detail)
    return rows, details

def run_benchmark(name, benchmark, models, temperatures, k=None, n=None, timeout=None, seed=42, seed_free=False, limit=0, force=False, selected_ids=None):
    cfg = load_config()
    k = int(k if k is not None else cfg["defaults"]["K"])
    n = int(n if n is not None else cfg["defaults"]["N"])
    timeout = float(timeout if timeout is not None else cfg["defaults"]["timeout"])
    root = results_dir(cfg) / name
    root.mkdir(parents=True, exist_ok=True)
    all_summaries = []
    for model in models:
        for temperature in temperatures:
            records = candidate_records(cfg, benchmark, model, temperature, k, root, force=force, limit=limit)
            rows, details = evaluate_candidate_records(records, cfg, n, timeout, seed, seed_free=seed_free, selected_ids=selected_ids)
            tag = f"{slug(benchmark)}_{slug(model)}_T{temperature}_K{k}_N{n}_seed{seed}"
            write_csv(root / f"{tag}_per_task.csv", rows)
            summary = summarize(rows)
            for item in summary:
                item.update({"benchmark": benchmark, "model": model, "temperature": temperature, "K": k, "N": n, "seed": seed, "timeout": timeout})
            write_csv(root / f"{tag}_summary.csv", summary)
            write_json(root / f"{tag}_details.json", details)
            all_summaries.extend(summary)
    write_csv(root / "summary_all.csv", all_summaries)
    return all_summaries

def rq1():
    cfg = load_config()
    return run_benchmark("rq1_lcb_main", "livecodebench", cfg["models"]["lcb"], [cfg["defaults"]["T"]])

def rq2_mbpp():
    cfg = load_config()
    return run_benchmark("rq2_mbpp", "mbpp", ["gpt-4o-mini"], [cfg["defaults"]["T"]])

def rq2_humaneval_x():
    cfg = load_config()
    outputs = []
    for benchmark in ["humaneval_x_python", "humaneval_x_java", "humaneval_x_cpp"]:
        outputs.extend(run_benchmark("rq2_humaneval_x", benchmark, ["gpt-4o-mini"], [cfg["defaults"]["T"]]))
    return outputs

def rq2_bigcodebench():
    cfg = load_config()
    return run_benchmark("rq2_bigcodebench", "bigcodebench", ["gpt-4o-mini"], [cfg["defaults"]["T"]])

def rq2_temperature_sweep():
    cfg = load_config("configs/ablations/temperature.yaml")
    return run_benchmark("rq2_temperature_sweep", cfg["benchmark"], [cfg["model"]], cfg["temperatures"])

def rq2_deepseek():
    cfg = load_config()
    return run_benchmark("rq2_deepseek", "livecodebench", cfg["models"]["deepseek"], [cfg["defaults"]["T"]])

def rq3_kn_sweep():
    cfg = load_config("configs/ablations/kn_sweep.yaml")
    results = []
    for k in cfg["K"]:
        for n in cfg["N"]:
            results.extend(run_benchmark("rq3_kn_sweep", cfg["benchmark"], [cfg["model"]], [load_config()["defaults"]["T"]], k=k, n=n))
    return results

def rq3_runtime():
    cfg = load_config()
    summaries = run_benchmark("rq3_runtime", "livecodebench", ["gpt-4o-mini"], [cfg["defaults"]["T"]])
    root = results_dir(cfg) / "rq3_runtime"
    rows = []
    for path in root.glob("*_per_task.csv"):
        with open(path, "r", encoding="utf-8") as handle:
            for row in csv.DictReader(handle):
                rows.append(float(row["runtime_seconds"]))
    runtime = {"mean_runtime_seconds": statistics.mean(rows) if rows else 0.0, "median_runtime_seconds": statistics.median(rows) if rows else 0.0, "tasks": len(rows)}
    write_csv(root / "runtime_summary.csv", [runtime])
    return summaries

def rq4_learned_weights():
    cfg = load_config("configs/ablations/learned_weights.yaml")
    base = load_config()
    rows, details = evaluate_candidate_records(candidate_records(base, cfg["benchmark"], "gpt-4o-mini", base["defaults"]["T"], base["defaults"]["K"], results_dir(base) / "rq4_learned_weights"), base, base["defaults"]["N"], base["defaults"]["timeout"], cfg["weights"]["seed"])
    merged = []
    by_id = {row["task_id"]: row for row in rows}
    for detail in details:
        item = dict(by_id[detail["task_id"]])
        item["outputs"] = detail["outputs"]
        merged.append(item)
    result = learn_weights(merged, cfg["weights"]["grid"], cfg["weights"]["split"], cfg["weights"]["seed"])
    root = results_dir(base) / "rq4_learned_weights"
    write_csv(root / "learned_weights.csv", [result])
    return result

def rq4_seed_free():
    cfg = load_config("configs/ablations/seed_free.yaml")
    base = load_config()
    return run_benchmark("rq4_seed_free", cfg["benchmark"], [cfg["model"]], [base["defaults"]["T"]], seed_free=True)

def rq4_fuzz_seeds():
    base = load_config()
    outputs = []
    for seed in [0, 1, 2]:
        outputs.extend(run_benchmark("rq4_fuzz_seeds", "livecodebench", ["gpt-4o-mini"], [base["defaults"]["T"]], seed=seed))
    return outputs

def appendix_diagnostics():
    cfg = load_config()
    run_benchmark("appendix_diagnostics", "livecodebench", ["gpt-4o-mini"], [cfg["defaults"]["T"]])
    root = results_dir(cfg) / "appendix_diagnostics"
    rows = []
    for path in root.glob("*_per_task.csv"):
        with open(path, "r", encoding="utf-8") as handle:
            rows.extend(csv.DictReader(handle))
    summary = []
    for key in ["valid_exec_rate", "unique_input_rate", "crash_pollution_rate", "line_coverage", "branch_coverage"]:
        values = [float(row[key]) for row in rows if row.get(key) not in {"", None}]
        summary.append({"metric": key, "mean": statistics.mean(values) if values else 0.0, "n": len(values)})
    write_csv(root / "input_quality_summary.csv", summary)
    return summary

def appendix_abstention():
    cfg = load_config()
    run_benchmark("appendix_abstention", "livecodebench", ["gpt-4o-mini"], [cfg["defaults"]["T"]])
    root = results_dir(cfg) / "appendix_abstention"
    rows = []
    for path in root.glob("*_per_task.csv"):
        with open(path, "r", encoding="utf-8") as handle:
            rows.extend(csv.DictReader(handle))
    output = []
    for metric in ["sde", "dsde"]:
        for fpr in [0.05, 0.20]:
            for item in abstention_cv(rows, metric, fpr):
                item.update({"metric": metric, "fpr_limit": fpr})
                output.append(item)
    write_csv(root / "abstention_cv.csv", output)
    return output

def appendix_timeout():
    cfg = load_config("configs/ablations/timeout.yaml")
    base = load_config()
    outputs = []
    for timeout in cfg["timeouts"]:
        outputs.extend(run_benchmark("appendix_timeout", cfg["benchmark"], [cfg["model"]], [base["defaults"]["T"]], timeout=timeout))
    return outputs

def appendix_case_studies():
    cfg = load_config()
    selected = {"3367", "abc332_b", "abc326_b", "3163"}
    return run_benchmark("appendix_case_studies", "livecodebench", ["gpt-4o-mini"], [cfg["defaults"]["T"]], selected_ids=selected)
