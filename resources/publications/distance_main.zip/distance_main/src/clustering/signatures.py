from collections import Counter

def normalize_signature(signature):
    return tuple(str(x) for x in signature)

def cluster_signatures(signatures):
    mapping = {}
    ids = []
    reps = {}
    for signature in signatures:
        key = normalize_signature(signature)
        if key not in mapping:
            cid = str(len(mapping))
            mapping[key] = cid
            reps[cid] = list(key)
        ids.append(mapping[key])
    counts = Counter(ids)
    total = len(ids)
    probs = {cid: count / total for cid, count in counts.items()} if total else {}
    return {"ids": ids, "representatives": reps, "probs": probs}
