from src.clustering.signatures import cluster_signatures
from src.metrics.distance import distance_matrix

def compute_sde_dsde(signatures, cfg):
    if not signatures:
        return {"sde": 0.0, "dsde": 0.0, "clusters": cluster_signatures([])}
    clusters = cluster_signatures(signatures)
    reps = clusters["representatives"]
    probs = clusters["probs"]
    ids, mat = distance_matrix(reps, cfg)
    sde = 0.0
    for i, left in enumerate(ids):
        for j in range(i + 1, len(ids)):
            right = ids[j]
            sde += probs.get(left, 0.0) * probs.get(right, 0.0) * mat[i, j]
    top = clusters["ids"][0] if clusters["ids"] else None
    dsde = 0.0
    if top is not None:
        top_index = ids.index(top)
        for j, cid in enumerate(ids):
            if cid != top:
                dsde += probs.get(cid, 0.0) * mat[top_index, j]
    return {"sde": float(sde), "dsde": float(dsde), "clusters": clusters}
