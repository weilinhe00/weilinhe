import numpy as np

def crash_type(value):
    text = str(value).strip()
    low = text.lower()
    if text == "":
        return text
    if "error" in low or "exception" in low or "timeout" in low:
        return text.split(":")[0]
    if text.startswith("<") and text.endswith(">"):
        return text
    return None

def outcome_distance(a, b, cfg):
    ca = crash_type(a)
    cb = crash_type(b)
    if ca is None and cb is None:
        return 0.0 if str(a) == str(b) else 1.0
    if (ca is None) != (cb is None):
        return float(cfg["a"])
    return float(cfg["c"]) if ca == cb else float(cfg["b"])

def signature_distance(sa, sb, cfg):
    n = min(len(sa), len(sb))
    if n == 0:
        return 0.0
    return sum(outcome_distance(sa[i], sb[i], cfg) for i in range(n)) / n

def distance_matrix(representatives, cfg):
    ids = list(representatives.keys())
    mat = np.zeros((len(ids), len(ids)))
    for i, left in enumerate(ids):
        for j in range(i + 1, len(ids)):
            right = ids[j]
            value = signature_distance(representatives[left], representatives[right], cfg)
            mat[i, j] = value
            mat[j, i] = value
    return ids, mat
