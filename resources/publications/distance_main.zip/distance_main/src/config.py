from pathlib import Path
import copy
import yaml

ROOT = Path(__file__).resolve().parents[1]

def deep_update(base, update):
    result = copy.deepcopy(base)
    for key, value in update.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = deep_update(result[key], value)
        else:
            result[key] = copy.deepcopy(value)
    return result

def read_yaml(path):
    with open(path, "r", encoding="utf-8") as handle:
        return yaml.safe_load(handle) or {}

def load_config(extra=None):
    cfg = read_yaml(ROOT / "configs" / "default.yaml")
    if extra:
        cfg = deep_update(cfg, read_yaml(ROOT / extra))
    return cfg

def path_from_root(value):
    path = Path(value)
    return path if path.is_absolute() else ROOT / path

def results_dir(cfg):
    path = path_from_root(cfg["paths"]["results"])
    path.mkdir(parents=True, exist_ok=True)
    return path

def data_path(cfg, benchmark):
    return path_from_root(cfg["benchmarks"][benchmark]["path"])

def distance_config(cfg):
    d = cfg["distance"]
    return {"a": float(d["a"]), "b": float(d["b"]), "c": float(d["c"])}
