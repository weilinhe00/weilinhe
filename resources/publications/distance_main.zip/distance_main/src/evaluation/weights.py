import random
from src.metrics.sde_dsde import compute_sde_dsde
from src.evaluation.stats import safe_auroc

def constrained_grid(values):
    for a in values:
        for b in values:
            for c in values:
                if a >= b >= c:
                    yield {"a": float(a), "b": float(b), "c": float(c)}

def split_rows(rows, ratio, seed):
    rng = random.Random(seed)
    shuffled = list(rows)
    rng.shuffle(shuffled)
    n = int(len(shuffled) * ratio)
    return shuffled[:n], shuffled[n:]

def score_rows(rows, cfg):
    values = []
    labels = []
    for row in rows:
        outputs = row.get("outputs", [])
        if not outputs:
            continue
        metric = compute_sde_dsde(outputs, cfg)
        values.append(metric["dsde"])
        labels.append(1 - int(float(row.get("pass_at_1", 0.0)) == 1.0))
    return safe_auroc(labels, values)

def learn_weights(rows, values, ratio=0.8, seed=42):
    train, test = split_rows(rows, ratio, seed)
    best = None
    for cfg in constrained_grid(values):
        score = score_rows(train, cfg)
        if best is None or score > best["train_auroc"]:
            best = {"cfg": cfg, "train_auroc": score}
    test_score = score_rows(test, best["cfg"]) if best else float("nan")
    return {"a": best["cfg"]["a"], "b": best["cfg"]["b"], "c": best["cfg"]["c"], "train_auroc": best["train_auroc"], "test_auroc": test_score}
