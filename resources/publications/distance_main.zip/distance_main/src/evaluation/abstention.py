import numpy as np
from sklearn.model_selection import KFold

def threshold_for_fpr(scores, failures, limit):
    pairs = sorted(zip(scores, failures), key=lambda x: x[0], reverse=True)
    best = None
    for score, _ in pairs:
        chosen = [s >= score for s in scores]
        fp = sum(1 for c, f in zip(chosen, failures) if c and not f)
        tn = sum(1 for c, f in zip(chosen, failures) if not c and not f)
        fpr = fp / (fp + tn) if fp + tn else 0.0
        if fpr <= limit:
            best = score
            break
    return best if best is not None else float("inf")

def abstention_cv(rows, metric, fpr_limit, folds=5, seed=42):
    scores = np.asarray([float(row[metric]) for row in rows])
    failures = np.asarray([1 - int(float(row.get("pass_at_1", 0.0)) == 1.0) for row in rows])
    kf = KFold(n_splits=folds, shuffle=True, random_state=seed)
    values = []
    for train, test in kf.split(scores):
        threshold = threshold_for_fpr(scores[train], failures[train], fpr_limit)
        chosen = scores[test] >= threshold
        fp = sum(1 for c, f in zip(chosen, failures[test]) if c and not f)
        tn = sum(1 for c, f in zip(chosen, failures[test]) if not c and not f)
        tp = sum(1 for c, f in zip(chosen, failures[test]) if c and f)
        fn = sum(1 for c, f in zip(chosen, failures[test]) if not c and f)
        fpr = fp / (fp + tn) if fp + tn else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        coverage = 1.0 - sum(chosen) / len(chosen)
        values.append({"fpr": fpr, "failure_recall": recall, "coverage": coverage})
    return values
