import csv
import math
from pathlib import Path
import numpy as np
from scipy.stats import pearsonr, spearmanr
from sklearn.metrics import roc_auc_score

def finite(value):
    return value is not None and not (isinstance(value, float) and math.isnan(value))

def safe_auroc(labels, scores):
    arr = np.asarray(labels)
    if len(set(arr.tolist())) < 2:
        return float("nan")
    try:
        return float(roc_auc_score(arr, np.asarray(scores)))
    except Exception:
        return float("nan")

def safe_corr(targets, scores):
    try:
        pr, _ = pearsonr(targets, scores)
        sp, _ = spearmanr(targets, scores)
        return float(pr), float(sp)
    except Exception:
        return float("nan"), float("nan")

def summarize(rows):
    groups = {"All": rows}
    for row in rows:
        groups.setdefault(row.get("difficulty", "Unknown"), []).append(row)
    out = []
    for name, items in groups.items():
        if not items:
            continue
        fail = [1 - int(float(x.get("pass_at_1", 0.0)) == 1.0) for x in items]
        partial = [float(x.get("partial_pass_at_1", x.get("pass_at_1", 0.0))) for x in items]
        sde = [float(x.get("sde", 0.0)) for x in items]
        dsde = [float(x.get("dsde", 0.0)) for x in items]
        psde, ssde = safe_corr(partial, sde)
        pdsde, sdsde = safe_corr(partial, dsde)
        out.append({
            "group": name,
            "n": len(items),
            "auroc_sde": safe_auroc(fail, sde),
            "auroc_dsde": safe_auroc(fail, dsde),
            "pearson_sde": psde,
            "pearson_dsde": pdsde,
            "spearman_sde": ssde,
            "spearman_dsde": sdsde,
        })
    return out

def write_csv(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
